using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DetectionRange : MonoBehaviour
{

    // for global variables

    public EnemyController enemyController;





    // Awake is called before the first frame update
    void Awake()
    {
        
    }

    // FixedUpdate is called once per frame
    void FixedUpdate()
    {
        
    }


    private void OnTriggerEnter(Collider other)
    {
        
        if (other.tag == "Player")
        {
            // if player in detection range play enemy run animation

            enemyController.Run();
            enemyController.playerInDetectionRange = true;
        }


    }


    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "Player")
        {
            enemyController.Walk();
            enemyController.playerInDetectionRange = true;
        }
    }



}
