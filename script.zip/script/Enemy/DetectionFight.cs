using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class DetectionFight : MonoBehaviour
{

    // for variables 

    public bool playInDetectionFight = false;
    public DateTime nextDamage;
    public float fightAfterTime;

    //for local component

    //for global component

    public EnemyController enemyControll;





    // Awake is called before the first frame update
    void Awake()
    {
        nextDamage = DateTime.Now;
    }

    // FixedUpdate is called once per frame
    void FixedUpdate()
    {

        // check if player in detaction fight to attack

        if (playInDetectionFight == true)
        {
            FightInDetectionFight();
        }
        
    }


    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            playInDetectionFight = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "Player")
        {
            playInDetectionFight = false;
        }
    }

    public void FightInDetectionFight()
    {
        if (nextDamage <= DateTime.Now)
        {
            enemyControll.Attack();
            nextDamage = DateTime.Now.AddSeconds(System.Convert.ToDouble(fightAfterTime));
        }
    }



}
