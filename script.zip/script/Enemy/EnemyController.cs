using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI; // to get navmesh agent

public class EnemyController : MonoBehaviour
{

    // for variables 

    // for local component

    private NavMeshAgent enemyNavMeshAgent;
    private Animator enemyAnimator;

    // for global component and game objects

    public Transform playerTransform;
    public bool playerInDetectionRange = false;







    // Awake is called before the first frame update
    void Awake()
    {
        enemyNavMeshAgent = GetComponent<NavMeshAgent>();
        enemyAnimator = GetComponent<Animator>();
    }

    // FixedUpdate is called once per frame
    void FixedUpdate()
    {
        // check if player in detection range to move enemy to play

        if (playerInDetectionRange == true)
        {
            enemyNavMeshAgent.transform.LookAt(playerTransform); // to make enemy look at player
            enemyNavMeshAgent.SetDestination(playerTransform.position + new Vector3(0, 0, 0.099f)); // move enemy to player
        }
    }

    // Start Walk Function

    public void Walk()
    {
        enemyNavMeshAgent.speed = 2.5f;
        enemyAnimator.SetTrigger("Walk");
    }

    //End Walk Function


    // Start Run Function

    public void Run()
    {
        enemyNavMeshAgent.speed = 5f;
        enemyAnimator.SetTrigger("Run");
    }

    // End Run Function

    // Start Attack Function 
    public void Attack()
    {
        enemyAnimator.SetTrigger("Attack1");
    }


    //End Attack Function






}
