using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; // to get canvas

public class PlayerHealth : MonoBehaviour
{

    // for variables of player health

    public float fullHealth;
    float currentHealth;
    public bool playerDied = false;

    // for component of player

    PlayerController pController;

    //for other game objects

    public Canvas playerCanvas;
    public Slider playerHealthSlider;



    // Awake is called before the first frame update
    void Awake()
    {

        currentHealth = fullHealth;
        playerHealthSlider.minValue = 0;
        playerHealthSlider.maxValue = fullHealth;
        playerHealthSlider.value = currentHealth;

        pController = GetComponent<PlayerController>();

        
    }

    // FixedUpdate is called once per frame
    void FixedUpdate()
    {
        
    }


    // Start AddDamage Function
     
    public void AddDamage(float damage)
    {
        currentHealth -= damage;
        playerHealthSlider.value = currentHealth;

        if (currentHealth <= 0)
        {
            playerDied = true;
            playerCanvas.enabled = false;
            pController.Death();
            pController.enabled = false;
        }
    }

    // End AddDamage Function 



}
